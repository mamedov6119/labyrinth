package labyrinth;
import javax.swing.*;

public class Labyrinth {
    
    private Board b;
    private JFrame f;

    public Labyrinth(String filepath) {
        
        b = new Board(filepath);
        f = new JFrame();
        f.setTitle("Labyrinth");
        f.add(b);
        f.setSize(506,529);
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        
    }
    
    public Board getBoard() {
        return this.b;
    }
    
    public JFrame getFrame() {
        return this.f;
    }
    
   


    
}
