/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labyrinth;
import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author murad
 */
public class Database {
    
    Connection con;
    
    String dburl = "jdbc:mysql://remotemysql.com:3306/92ISMzVba3";
    String pass = "CQCbpcDWFn";
    String user = "92ISMzVba3";
    
    public Database() {
        try {
            con = DriverManager.getConnection(dburl, user, pass);
        } catch (SQLException e) {
            System.out.println("Connection lost! " + e.getMessage());
            
        }
    }
    
    public void createTable(JTable player_table) {
        try {
            String sql = "SELECT * FROM HighScores";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            ResultSetMetaData rsmd  = rs.getMetaData();
            
            DefaultTableModel model = (DefaultTableModel) player_table.getModel();
            
            int cols = rsmd.getColumnCount();
            String[] colName = new String[cols];
            for (int i = 0; i < cols; i++) {
                colName[i] = rsmd.getColumnName(i+1);
                model.setColumnIdentifiers(colName);
                
            }
            
            
            String no, name, score;
            while(rs.next()) {
                no = rs.getString(1);
                name = rs.getString(2);
                score = rs.getString(3);
                String[] row = {no, name, score};
                model.addRow(row);

            }
            
        } catch (SQLException e) {
            
        }
    }
    
    public void how_many_lab(String name, int how_many, int score) throws SQLException {
        Statement st = con.createStatement();
        String sql = "INSERT INTO HighScores (name, lvls, score) VALUES ('" + name + "'," + how_many + "," + score + ")";
        st.executeUpdate(sql);
    }
    
    
    
    
   
}
