package labyrinth;
import java.awt.*;
import javax.swing.ImageIcon;

public class Dragon {
    private int tileX, tileY;
    private Image dragon;
    private int actionLockcnt = 0;
    public Dragon() {
        ImageIcon img = new ImageIcon("C:\\Users\\murad\\Desktop\\dragon1.gif");
        dragon = img.getImage();
    }
    
        public Image getDragon() {
        return dragon;
    }

    public int getTileX() {
        return tileX;
    }

    public int getTileY() {
        return tileY;
    }
    
    public void setTiles(int tileX, int tileY) {
        this.tileX = tileX;
        this.tileY = tileY;
    }
    
    public void movement(int tx, int ty) {
        tileX += tx;
        tileY += ty;
    }
    
    public int getActionLock() {
        return this.actionLockcnt;
    }
    
    public void addActionLock(int i) {
        this.actionLockcnt += i;
    }
    public void setActionLock() {
        this.actionLockcnt = 0;
    }
}
