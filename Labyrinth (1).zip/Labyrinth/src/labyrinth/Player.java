package labyrinth;

import java.awt.*;
import javax.swing.ImageIcon;


public class Player {

    private int tileX, tileY;
    private Image player;
    private int life = 1;
    public Player() {
        ImageIcon img = new ImageIcon("C:\\Users\\murad\\Desktop\\player.png");
        player = img.getImage();
        
        tileX = 1;
        tileY = 12;
    }
    
    public boolean alive() {
        if (this.life == 0) {
            return false;
        } 
        return true;
    }
    
    public Image getPlayer() {
        return player;
    }

    public int getTileX() {
        return tileX;
    }

    public int getTileY() {
        return tileY;
    }
    
    
    public void setTiles(int x, int y ) {
        this.tileX = x;
        this.tileY = y;
    }
    
    public void movement(int tx, int ty) {

        tileX += tx;
        tileY += ty;
    }
}
