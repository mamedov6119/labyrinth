package labyrinth;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.SQLException;
import java.util.HashSet;
import static java.util.Locale.filter;
import javax.swing.*;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;


public class Board extends JPanel implements ActionListener{
    
    private int tileXD;
    private int tileYD;
    
    private int cnt_of_solved = 0;
    private int timeSeconds;
    
    Random rand = new Random();
    private String userId = "Insert your name!" + rand.nextInt(1000000000);

    private boolean can_spaw_dragon;
    
    private Timer timer;
    
    private Image no_vision;
        
    private boolean dead = false;
    
    private boolean timer_started = false;
    
    private Map m;
    
    private Player p;
    
    private Dragon d;
    
    private boolean win = false;
    private boolean lose = false;
    
    private Font font = new Font("Serif", Font.BOLD, 48);
    Database b;
    private String Message = "";
    
    private Timer t = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timeSeconds += 1;
            }
        });
    
    public Board(String filepath) {
        b = new Database();
        
        can_spaw_dragon = false;
        if (timer_started == false) {
            timer_started = true;
            t.start();
        } else {
            timer_started = false;
            t.stop();   
        }
        
        m = new Map(filepath);
        p = new Player();
        d = new Dragon();
        addKeyListener(new AL());
        setFocusable(true);
        
        timer = new Timer(25, this);
        
        
        timer.start();
        
    }
    
    public int getSolved() {
        return this.cnt_of_solved;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (m.getMap(p.getTileX(), p.getTileY()).equals("f")) {
            Message = "WINNER!";
            win = true;
        } 
        if (p.getTileX() == d.getTileX() && p.getTileY() == d.getTileY() ||
                p.getTileX() == d.getTileX() + 1 && p.getTileY() == d.getTileY() ||
                p.getTileX() == d.getTileX() - 1 && p.getTileY() == d.getTileY() ||
                p.getTileX() == d.getTileX() && p.getTileY() == d.getTileY() - 1 ||
                p.getTileX() == d.getTileX() && p.getTileY() == d.getTileY() + 1 ) {
            Message = "YOU DIED!";
            dead = true;
            lose = true;
        }
        
        repaint();
    }
    
    
    public void paint(Graphics g) {
        
        while(!this.can_spaw_dragon) {
            this.tileXD = rand.nextInt(14);
            this.tileYD = rand.nextInt(14);
            
            if (m.getMap(tileXD, tileYD).equals("p")) {
                this.can_spaw_dragon = true;
                d.setTiles(this.tileXD, this.tileYD);
                
            }
            
        }
        
        ImageIcon img = new ImageIcon("src\\labyrinth\\no_vision.png");
        no_vision = img.getImage();
        boolean in_vision = false;
        super.paint(g);

       if (!win && !lose) {
           

        for (int y = 0; y < 14; y++) {

            for (int x = 0; x < 14; x++) {
                
                if (x - 2 <= p.getTileX() && p.getTileX() <= x + 2 && y - 2 <= p.getTileY() && p.getTileY() <= y + 2) {
//                if (p.getTileX() == x  && p.getTileY() == y || p.getTileX() == x  && p.getTileY() + 1 == y || p.getTileX() == x  && p.getTileY() - 1 == y || p.getTileX() + 1 == x  && p.getTileY() == y || p.getTileX() -1 == x  && p.getTileY() == y || p.getTileX() - 1 == x  && p.getTileY() + 1 == y || p.getTileX() + 1 == x  && p.getTileY() + 1 == y || p.getTileX() - 1 == x  && p.getTileY() - 1 == y || p.getTileX() + 1 == x  && p.getTileY() - 1 == y || p.getTileX() + 2 == x  && p.getTileY() == y || p.getTileX() + 2 == x  && p.getTileY() + 1 == y || p.getTileX() + 2 == x  && p.getTileY() - 1 == y || p.getTileX() + 1 == x  && p.getTileY() - 2 == y || p.getTileX() + 2 == x  && p.getTileY() - 2 == y || p.getTileX() - 2 == x  && p.getTileY() + 1 == y || p.getTileX() - 2 == x  && p.getTileY() + 2 == y || p.getTileX() - 1 == x  && p.getTileY() + 2 == y || p.getTileX() == x  && p.getTileY() + 2 == y || p.getTileX() + 1 == x  && p.getTileY() + 2 == y || p.getTileX() + 2 == x  && p.getTileY() + 2 == y || p.getTileX() -1 == x  && p.getTileY() - 2 == y || p.getTileX() == x  && p.getTileY() - 2 == y || p.getTileX() -2 == x  && p.getTileY()  == y ||  p.getTileX() -2 == x  && p.getTileY() -1 == y ||  p.getTileX() -2 == x  && p.getTileY() -2 == y) {
                
                if (m.getMap(x, y).equals("f")) g.drawImage(m.getFinish(), x * 35, y * 35, null);
                
                
                
                if(m.getMap(x, y).equals("p")) {
                    g.drawImage(m.getPath(), x * 35, y * 35, null);
                }
                if(m.getMap(x, y).equals("w")) {
                    g.drawImage(m.getWall(), x * 35, y * 35, null);
                }
                
                
                } else {
                    g.drawImage(no_vision, x*35, y*35, null); 
                }
                
                
                    
               
            }
            
        }       
        
        if (p.getTileX() - 2 <= d.getTileX() && d.getTileX() <= p.getTileX() + 2 && p.getTileY() - 2 <= d.getTileY() && d.getTileY() <= p.getTileY() + 2) {
            g.drawImage(d.getDragon(), d.getTileX()*35, d.getTileY()*35, null);

        }


            g.drawImage(p.getPlayer(), p.getTileX() * 35 + 7 , p.getTileY() * 35 + 7, null);
            
       }
        d.addActionLock(1);
        if (d.getActionLock() == 120) {
            int dir = rand.nextInt(4);
            if (dir  == 0) {
                if(!m.getMap(d.getTileX(), d.getTileY() - 1).equals("w")){
                    d.movement(0, -1);
                }
            }
            else if (dir  == 1) {
                if(!m.getMap(d.getTileX(), d.getTileY() + 1).equals("w")) {
                    d.movement(0, 1);
                }
            }
            else if (dir  == 2) {
                if(!m.getMap(d.getTileX() - 1, d.getTileY()).equals("w") ) {
                    d.movement(-1, 0);
                }
            }
            else if (dir  == 3) {
                if(!m.getMap(d.getTileX() + 1, d.getTileY()).equals("w") ) {
                    d.movement(1, 0);
                }
            }
            
            d.setActionLock();
            
        }
       
       if (win) {
            can_spaw_dragon = false;
            win = false;
            
            cnt_of_solved++;
            p.setTiles(1, 12);
            System.out.println(cnt_of_solved);
            g.setColor(Color.GREEN );
            g.setFont(font);
            g.drawString(Message, 140, 250);
            g.drawString("Time: "+timeSeconds, 180, 100);
       }
       if (lose) {
           if (dead) {
            lose = false;
            try {
                b.how_many_lab(userId, cnt_of_solved, timeSeconds);
            } catch (SQLException ex) {
                Logger.getLogger(Board.class.getName()).log(Level.SEVERE, null, ex);
            }
           }
            g.setColor(Color.GREEN );
            g.setFont(font);
            g.drawString(Message, 140, 250);
            g.drawString("Time: "+timeSeconds, 180, 100);
            g.drawString("Solved labyrinth: "+cnt_of_solved, 70, 50);
            t.stop();
            
       }
        
    }
    
    
 
  

public class AL extends KeyAdapter {

    @Override
    public void keyPressed(KeyEvent e) {
        int keycode = e.getKeyCode();
        
        if (keycode  == KeyEvent.VK_W) {
            if(!m.getMap(p.getTileX(), p.getTileY() - 1).equals("w")) p.movement(0, -1);
        }
        if (keycode  == KeyEvent.VK_S) {
            if(!m.getMap(p.getTileX(), p.getTileY() + 1).equals("w")) p.movement(0, 1);
        }
        if (keycode  == KeyEvent.VK_A) {
            if(!m.getMap(p.getTileX() - 1, p.getTileY()).equals("w") ) p.movement(-1, 0);
        }
        if (keycode  == KeyEvent.VK_D) {
            if(!m.getMap(p.getTileX() + 1, p.getTileY()).equals("w") ) p.movement(1, 0);
        }
            
        }
        
        
        
//        && !m.getMap(p.getTileX() + 1, p.getTileY()+1).equals("w")
//&& !m.getMap(p.getTileX() - 1, p.getTileY()+1).equals("w")


    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }
     
    
    
    
}

    
}
