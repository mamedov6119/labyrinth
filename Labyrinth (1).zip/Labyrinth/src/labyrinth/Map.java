package labyrinth;

import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.ImageIcon;


public class Map {
    
    private Scanner m;
    private String Map[] = new String[14];
    private Image wall, path, finish;
    
    public Map(String filepath) {
        
        ImageIcon img = new ImageIcon("C:\\Users\\murad\\Documents\\NetBeansProjects\\Labyrinth\\src\\labyrinth\\tile73.png");
        wall = img.getImage();
        img = new ImageIcon("C:\\Users\\murad\\Documents\\NetBeansProjects\\Labyrinth\\src\\labyrinth\\tile5.png");
        path = img.getImage();
        img = new ImageIcon("C:\\Users\\murad\\Desktop\\Door_Finish\\door1.png");
        finish = img.getImage();
        
        openFile(filepath);
        readFile();
        closeFile();
    }

    public Image getPath() {
        return path;
    }
    
    public Image getWall() {
        return wall;
    }
    
    public Image getFinish() {
        return finish;
    }

    
    
    public String getMap(int x, int y) {
        String index = Map[y].substring(x,x+1);
        return index;
    }
    
    public void openFile( String filepath) {
        try {
            m = new Scanner(new File(filepath));

        } catch (FileNotFoundException e) {
            System.out.println("Problem occured while loading a map."); 
        }
    }

    public void readFile() {
        while(m.hasNext()) {
            for (int i = 0; i < 14; i++) {
                Map[i] = m.next();
            }
        }
    }

    public void closeFile() {
        m.close();
    }

}
